// participante.js

class Participante {
    constructor(id, nome, email, matricula, evento) {
      this.id = id;
      this.nome = nome;
      this.email = email;
      this.nome = matricula;
      this.evento = evento;
    }
  }
  