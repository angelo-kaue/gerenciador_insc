// script.js

document.addEventListener('DOMContentLoaded', () => {
  const gerenciador = new GerenciadorDeInscricoes();

  const formAdicionarParticipante = document.getElementById('formAdicionarParticipante');
  const listaParticipantes = document.getElementById('listaParticipantes');
  const mensagens = document.getElementById('mensagens');

  const adicionarParticipanteNaLista = (participante) => {
    const li = document.createElement('li');
    li.className = 'list-group-item d-flex justify-content-between align-items-center';
    li.innerHTML = `
      ${participante.nome} (${participante.email}, ${participante.matricula}) - ${participante.evento}
      <button class="btn btn-danger btn-sm" onclick="excluirParticipante(${participante.id})">Excluir</button>
    `;
    listaParticipantes.appendChild(li);
  };

  const atualizarListaParticipantes = () => {
    listaParticipantes.innerHTML = '';
    gerenciador.listarParticipantes().forEach(adicionarParticipanteNaLista);
  };

  const exibirMensagem = (mensagem, tipo) => {
    const div = document.createElement('div');
    div.className = `alert alert-${tipo}`;
    div.appendChild(document.createTextNode(mensagem));
    mensagens.appendChild(div);
    setTimeout(() => div.remove(), 3000);
  };

  const salvarDados = () => {
    localStorage.setItem('participantes', JSON.stringify(gerenciador.listarParticipantes()));
  };

  const carregarDados = () => {
    const dados = localStorage.getItem('participantes');
    if (dados) {
      const participantes = JSON.parse(dados);
      participantes.forEach(participante => gerenciador.adicionarParticipante(participante.nome, participante.email, participante.matricula, participante.evento));
      atualizarListaParticipantes();
    }
  };

  window.excluirParticipante = (id) => {
    gerenciador.excluirParticipante(id);
    atualizarListaParticipantes();
    salvarDados();
    exibirMensagem('Participante excluído com sucesso!', 'success');
  };

  formAdicionarParticipante.addEventListener('submit', (event) => {
    event.preventDefault();
    const nome = document.getElementById('nome').value;
    const email = document.getElementById('email').value;
    const matricula = document.getElementById('matricula').value;
    const evento = document.getElementById('evento').value;

    if (nome && email && matricula && evento) {
      const participante = gerenciador.adicionarParticipante(nome, email, matricula, evento);
      adicionarParticipanteNaLista(participante);
      formAdicionarParticipante.reset();
      salvarDados();
      exibirMensagem('Participante adicionado com sucesso!', 'success');
    } else {
      exibirMensagem('Todos os campos são obrigatórios.', 'danger');
    }
  });

  carregarDados();
  atualizarListaParticipantes();
});
