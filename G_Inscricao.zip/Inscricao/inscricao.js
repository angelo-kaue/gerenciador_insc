class Participante {
    constructor(nome, email, matricula) {
        this.nome = nome;
        this.email = email;
        this.matricula = matricula;
    }
}

class Evento {
    constructor(nome) {
        this.nome = nome;
        this.participantes = [];
    }

    inscrever(participante) {
        this.participantes.push(participante);
        console.log(`${participante.nome} se inscreveu para o evento ${this.nome}!`);
    }

    listarInscritos(elemento) {
        elemento.innerHTML = '';
        this.participantes.forEach(participante => {
            let li = document.createElement('li');
            li.textContent = `Nome: ${participante.nome}, Email: ${participante.email}, Matricula: ${participante.matricula}`;
            li.classList.add('list-group-item');
            elemento.appendChild(li);
        });
    }
}

let eventos = [];

document.getElementById('formEvento').addEventListener('submit', function(e) {
    e.preventDefault();
    let nomeEvento = document.getElementById('nomeEvento').value;
    let evento = new Evento(nomeEvento);
    eventos.push(evento);

    let select = document.getElementById('evento');
    let option = document.createElement('option');
    option.textContent = nomeEvento;
    option.value = nomeEvento;
    select.appendChild(option);

    let div = document.createElement('div');
    div.id = 'evento-' + nomeEvento;
    div.innerHTML = `<h3>${nomeEvento}</h3><ul class="list-group"></ul>`;
    document.getElementById('listaEventos').appendChild(div);
});

document.getElementById('formInscricao').addEventListener('submit', function(e) {
    e.preventDefault();
    let nomeEvento = document.getElementById('evento').value;
    let nome = document.getElementById('nome').value;
    let email = document.getElementById('email').value;
    let matricula = document.getElementById('matricula').value;
    let participante = new Participante(nome, email, matricula);

    let evento = eventos.find(e => e.nome === nomeEvento);
    evento.inscrever(participante);

    let ul = document.querySelector('#evento-' + nomeEvento + ' ul');
    evento.listarInscritos(ul);
});
