// gerenciadorDeInscricoes.js

class GerenciadorDeInscricoes {
  constructor() {
    this.participantes = [];
    this.proximoId = 1;
  }

  adicionarParticipante(nome, email, matricula, evento) {
    const novoParticipante = new Participante(this.proximoId, nome, email, matricula, evento);
    this.participantes.push(novoParticipante);
    this.proximoId++;
    return novoParticipante;
  }

  listarParticipantes() {
    return this.participantes;
  }

  excluirParticipante(id) {
    this.participantes = this.participantes.filter(participante => participante.id !== id);
  }
}
